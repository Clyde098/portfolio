#include <iostream>
using namespace std;

// ==========================================
// PROVIDED CODE - DO NOT MODIFY
// ==========================================

struct Node
{
    int data;
    Node* next;
};

// ==========================================
// STUDENT CODE
// ==========================================

void solve(int n)
{
    /*
        SIGNAL RELAY REPAIR

        Write your solution here.

        Requirements:
        1. Create a singly linked list containing n relay IDs.
        2. Read the n relay IDs from input.
        3. Find unstable nodes.

           A node is unstable if:
               node < previous node
           AND
               node < next node

        4. The first and last nodes cannot be removed.
        5. Whenever an unstable node is removed:
              - reconnect the linked list properly
              - delete the removed node
              - restart checking from the beginning

        6. Continue until no unstable node remains.

        7. Print the final linked list in this format:

              value1 value2 value3 ...

           Then print:

              Removed: X

        Restrictions:
        - You must use a singly linked list.
        - Do NOT use arrays to store the relay IDs.
        - Do NOT use vector.
        - Do NOT use list.
        - Do NOT use forward_list.
        - Do NOT use deque.
        - Do NOT use other STL containers to
          simulate the linked list.
    */
    int removedCount = 0;
    
    auto removeUnstableNode = [&](Node* dummyHead) -> bool {
        Node* prev = dummyHead->next;
        
        if (prev == nullptr || prev->next == nullptr)
        {
            return false;
        }
        
        Node* curr = prev->next;
        
        while (curr != nullptr && curr->next != nullptr)
        {
            Node* nextNode = curr->next;
            
            if (curr->data < prev->data && curr->data < nextNode->data)
            {
                prev->next = nextNode;
                
                delete curr;
                removedCount++;
                return true;
            }
            
            prev = curr;
            curr = nextNode;
        }
        
        return false;
    };
    
    Node* dummyHead = new Node{-1, nullptr};
    Node* tail = dummyHead;
    
    for (int i = 0; i < n; i++)
    {
        int val;
        cin >> val;
        tail->next = new Node{val, nullptr};
        tail = tail->next;
    }
    
    while (removeUnstableNode(dummyHead))
    {
        //loop continues
    }
    
    Node* curr = dummyHead->next;
    bool isFirst = true;
    while (curr != nullptr)
    {
        if (!isFirst)
        {
            cout << " ";
        }
        cout << curr->data;
        isFirst = false;
        curr = curr->next;
    }
    
    cout << "\n";
    
    cout << "Removed: " << removedCount;
    
    curr = dummyHead;
    while (curr != nullptr)
    {
        Node* temp = curr;
        curr = curr->next;
        delete temp;
    }
}


// ==========================================
// PROVIDED CODE - DO NOT MODIFY
// ==========================================

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;

    solve(n);

    return 0;
}