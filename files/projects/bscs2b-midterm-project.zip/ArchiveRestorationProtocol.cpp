#include <iostream>
using namespace std;

// =====================================================
// STUDENT CODE
// =====================================================
struct Node {
    int id;
    bool locked;
    Node* prev;
    Node* next;
    
    Node(int val) : id(val), locked(false), prev(nullptr), next(nullptr) {}
};
void solve(int n)
{
    /*
        ARCHIVE RESTORATION PROTOCOL

        Write your solution here.

        The next n integers from the input are the
        record IDs in their original order.

        Your program must simulate the restoration
        protocol exactly as described in the problem.

        OUTPUT FORMAT:

        Print the final sequence:

        value1 value2 value3 ...

        Then print:

        Removed: X
        Moved: Y


        IMPORTANT:
        - Follow the restoration rules exactly.
        - Inspection is performed from left to right.
        - The first matching rule must be applied.
        - After a record is removed or moved,
          restart inspection from the beginning.
        - A record moved by Rule 2 becomes locked.
        - A locked record cannot be moved by Rule 2 again.
        - A locked record may still be removed by Rule 1.
        - Stop only when one complete inspection
          causes no removal or movement.


        RESTRICTIONS:
        - Do NOT use arrays to store the record sequence.
        - Do NOT use vector.
        - Do NOT use list.
        - Do NOT use forward_list.
        - Do NOT use deque.
        - Do NOT use stack or queue.
        - Do NOT use other STL containers to represent
          or manipulate the record sequence.
    */


    // WRITE YOUR CODE HERE
    if (n <= 0) return;
    
    Node* head = nullptr;
    Node* tail = nullptr;
    
    for (int i = 0; i < n; i++)
    {
        int val;
        cin >> val;
        Node* newNode = new Node(val);
        if (!head)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    }
    
    int removed_count = 0;
    int moved_count = 0;
    
    while (true)
    {
        bool changed = false;
        Node* curr = head->next;
        
        while (curr != nullptr && curr != tail)
        {
            Node* L = curr->prev;
            Node* R = curr->next;
            
            if (curr->id < L->id && curr->id < R->id)
            {
                L->next = R;
                R->prev = L;
                
                delete curr;
                removed_count++;
                changed = true;
                break;
            }
            
            if (curr->id > L->id && curr->id > R->id && !curr->locked)
            {
                L->next = R;
                R->prev =L;
                
                if (L->id < R->id)
                {
                    curr->prev = R;
                    curr->next = R->next;
                    if (R->next != nullptr)
                    {
                        R->next->prev = curr;
                    }
                    else
                    {
                        tail = curr;
                    }
                    R->next = curr;
                }
                else
                {
                    curr->prev = L->prev;
                    curr->next = L;
                    if (L->prev != nullptr)
                    {
                        L->prev->next = curr;
                    }
                    else
                    {
                        head = curr;
                    }
                    L->prev = curr;
                }
                
                curr->locked = true;
                moved_count++;
                changed = true;
                break;
            }
            
            curr = curr->next;
        }
        
        if (!changed)
        {
            break;
        }
    }
    
    Node* temp = head;
    bool first = true;
    while (temp != nullptr)
    {
        if (!first) cout << " ";
        cout << temp->id;
        first = false;
        temp = temp->next;
    }
    
    cout << endl;
    cout << "Removed: " << removed_count << endl;
    cout << "Moved: " << moved_count;
    
    temp = head;
    while (temp != nullptr)
    {
        Node* nextNode = temp->next;
        delete temp;
        temp = nextNode;
    }
}


// =====================================================
// PROVIDED CODE - DO NOT MODIFY
// =====================================================

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;

    solve(n);

    return 0;
}