#include <iostream>
using namespace std;

#define SIZE 5

// ============================================================
// STUDENT WORK AREA
// ============================================================

// Create your Queue data structure here.
//
// Requirements:
// - Use an array-based queue.
// - Maximum size is SIZE.
// - Implement the necessary queue operations.
//
// You may create:
//   class Queue
//
// Suggested operations:
//   enqueue()
//   dequeue()
//   peek()
//   isEmpty()
//   isFull()
//
// Do NOT use:
//   std::queue
//   vector
//   list
//   deque
//
// ------------------------------------------------------------


// WRITE YOUR QUEUE IMPLEMENTATION BELOW

class Queue {
private:
    int items[SIZE];
    int front;
    int rear;
    int count;
public:
    Queue() {
        front = 0;
        rear = -1;
        count = 0;
    }
    
    bool isFull() {
        return count >= SIZE;
    }
    
    bool isEmpty() {
        return count <= 0;
    }
    
    void enqueue(int val) {
        if (!isFull()) {
            rear = (rear + 1) % SIZE;
            items[rear] = val;
            count++;
        }
    }
    
    int dequeue() {
        if (!isEmpty()) {
            int val = items[front];
            front = (front + 1) % SIZE;
            count--;
            return val;
        }
        return 0;
    }
};






// WRITE YOUR QUEUE IMPLEMENTATION ABOVE


void solve(int N, int tokens[])
{
    // --------------------------------------------------------
    // CAMPUS GATE TOKEN RELAY
    //
    // You must use your own Queue data structure.
    // --------------------------------------------------------


    // WRITE YOUR SOLUTION BELOW

    Queue q;
    
    for (int i = 0; i < N; i++) {
        q.enqueue(tokens[i]);
    }

    int totalPoints = 0;
    int processed_count = 0;
    
    while (!q.isEmpty()) {
        int token = q.dequeue();
        int points = 0;
        
        if (token % 2 == 0) {
            points += token * 2;
        }
        else {
            points += token + 5;
        }
        
        cout << points << endl;
        totalPoints += points;
        processed_count++;
    }


    cout << "Total Points: " << totalPoints;


    // WRITE YOUR SOLUTION ABOVE
}


// ============================================================
// DO NOT MODIFY THIS SECTION
// ============================================================

int main()
{
    int N;
    cin >> N;

    int tokens[SIZE];

    for (int i = 0; i < N; i++)
    {
        cin >> tokens[i];
    }

    solve(N, tokens);

    return 0;
}