#include <iostream>
using namespace std;

#define MAX 5

// ============================================================
// PROVIDED STACK CLASS
// DO NOT MODIFY THIS CLASS
// ============================================================

class Stack
{
private:
    int arr[MAX];
    int top;

public:
    Stack()
    {
        top = -1;
    }

    bool isEmpty()
    {
        return (top == -1);
    }

    bool isFull()
    {
        return (top == MAX - 1);
    }

    bool push(int data)
    {
        if (isFull())
        {
            return false;
        }

        top = top + 1;
        arr[top] = data;
        return true;
    }

    bool pop()
    {
        if (isEmpty())
        {
            return false;
        }

        top = top - 1;
        return true;
    }

    int peek()
    {
        if (isEmpty())
        {
            return -1;
        }

        return arr[top];
    }

    void display()
    {
        if (isEmpty())
        {
            return;
        }

        for (int i = 0; i <= top; i++)
        {
            cout << arr[i] << " ";
        }
    }
};

// ============================================================
// STUDENT CODE
// Write your solution ONLY inside the solve() function.
//
// RULES:
// 1. You MUST use the provided Stack class.
// 2. Do NOT modify the Stack class.
// 3. Do NOT create another stack class.
// 4. Do NOT use std::stack or other STL containers.
// 5. Do NOT use arrays to perform the reversal.
// ============================================================

void solve()
{
    // Write your solution here.
    
    Stack s;
    int firstCode;
    int val;
    
    for (int i = 0; i < 5; i++) {
        cin >> val;
        if (i == 0) {
            firstCode = val;
        }
        s.push(val);
    }
    
    int count = 0;
    cout << "Reversed:";
    
    while (!s.isEmpty()) {
        int current = s.peek();
        s.pop();
        
        cout << " " << current;
        
        if (current > firstCode) {
            count++;
        }
    }
    cout << endl;
    cout << "Count: " << count;
}

// ============================================================
// DO NOT MODIFY
// ============================================================

int main()
{
    solve();
    return 0;
}