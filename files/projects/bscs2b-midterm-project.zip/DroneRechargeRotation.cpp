#include <iostream>
using namespace std;

#define SIZE 5


// ============================================================
// STUDENT WORK AREA
// ============================================================

// Create the data structure needed to represent a Drone.
//
// Each drone must contain:
//   - ID
//   - Battery level
//
//
// The queue must be able to store Drone data.
//
// You may implement operations such as:
//   enqueue()
//   dequeue()
//   peek()
//   isEmpty()
//   isFull()
//
// IMPORTANT:
// The queue must support removing an item from the front
// and inserting an item again at the rear.
//
// DO NOT use:
//   std::queue
//   vector
//   deque
//   list
//
// ------------------------------------------------------------


// WRITE YOUR DATA STRUCTURES BELOW
struct Drone {
    int id;
    int battery;
};

class Queue {
private:
    Drone items[SIZE];
    int frontIndex;
    int rearIndex;
    int count;
    
public:
    Queue() {
        frontIndex = 0;
        rearIndex = 0;
        count = 0;
    }
    
    bool isFull() {
        return count == SIZE;
    }
    
    bool isEmpty() {
        return count == 0;
    }

    void enqueue(Drone d) {
        if (!isFull()) {
            items[rearIndex] = d;
            rearIndex = (rearIndex + 1) % SIZE;
            count++;
        }
    }

    Drone dequeue() {
        Drone d = {-1, -1};
        if (!isEmpty()) {
            d = items[frontIndex];
            frontIndex = (frontIndex + 1) % SIZE;
            count--;
        }
        
        return d;
    }
};
// WRITE YOUR DATA STRUCTURES ABOVE



void solve(int N, int ids[], int batteries[])
{
    // ========================================================
    // DRONE RECHARGE ROTATION
    // ========================================================

    // WRITE YOUR SOLUTION BELOW
    Queue q;
    
    for (int i = 0; i < N; i++) {
        Drone d;
        d.id = ids[i];
        d.battery = batteries[i];
        q.enqueue(d);
    }
    
    int inspections = 0;
    
    while (!q.isEmpty()) {
        Drone current = q.dequeue();
        inspections++;
        
        if (current.battery >= 60) {
            cout << "Drone " << current.id << " launched at " << current.battery << endl;
        }
        else {
            if (current.id % 2 != 0) {
                current.battery += 17;
            }
            else{
                current.battery += 13;
            }
            
            if (current.battery > 100) {
                current.battery = 100;
            }
            
            q.enqueue(current);
        }
    }
    
    cout << "Total Inspections: " << inspections;
    // WRITE YOUR SOLUTION ABOVE
}



// ============================================================
// DO NOT MODIFY THIS SECTION
// ============================================================

int main()
{
    int N;
    cin >> N;

    int ids[SIZE];
    int batteries[SIZE];

    for (int i = 0; i < N; i++)
    {
        cin >> ids[i] >> batteries[i];
    }

    solve(N, ids, batteries);

    return 0;
}