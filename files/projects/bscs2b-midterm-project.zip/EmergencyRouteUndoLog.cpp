#include <iostream>
#include <string>
using namespace std;

#define MAX 5

// ============================================================
// DATA TYPE FOR EACH ROUTE ACTION
// ============================================================

struct Action
{
    string roomCode;
    int movement;
};


// ============================================================
// STACK CLASS
//
// You may MODIFY this class as needed to make the stack
// work correctly with the Action data type.
//
// Required operations:
//   push()
//   pop()
//   peek()
//   isEmpty()
//   isFull()
//
// The stack must remain ARRAY-BASED.
// Do NOT use std::stack or other STL containers.
// ============================================================

class Stack
{
private:
    // Modify the data type if necessary.
    // The stack must be able to store Action records.

    // YOUR CODE HERE

    Action data[MAX];
    
    int top;
    
public:

    // Constructor
    Stack()
    {
        // YOUR CODE HERE
        
        top = -1;
    }


    bool isEmpty()
    {
        // YOUR CODE HERE
        return top == -1;
    }


    bool isFull()
    {
        // YOUR CODE HERE
        return top == MAX - 1;
    }


    bool push(Action data)
    {
        // YOUR CODE HERE
        
        if (isFull()) {
            return false;
        }
        
        top++;
        this->data[top] = data;
        return true;
    }


    bool pop()
    {
        // YOUR CODE HERE
        if (isEmpty()) {
            return false;
        }
        
        top--;
        return true;
    }


    Action peek()
    {
        // YOUR CODE HERE
        return data[top];
    }
};


// ============================================================
// SOLVE THE PROBLEM
//
// Requirements:
// 1. Read exactly 5 route actions.
// 2. Store all actions in your Stack.
// 3. Process them in LIFO order.
// 4. Display the retreat order.
// 5. Count the critical retreat points.
// 6. Display the room with the highest movement value.
//
// You MUST use your Stack operations when processing
// the retreat order.
// ============================================================

void solve()
{
    Stack s;

    // WRITE YOUR SOLUTION HERE

    string code;
    int movement;
    
    int highestMovement = -1;
    string highestRoom = "";

    for (int i = 0; i < 5; i++) {
        cin >> code >> movement;
        
        if (movement >= highestMovement) {
            highestMovement = movement;
            highestRoom = code;
        }
        
        Action a;
        
        a.roomCode = code;
        a.movement = movement;
        
        s.push(a);
    }
    
    int criticalCount = 0;
    int premovement = -1;
    
    while (!s.isEmpty()) {
        Action current = s.peek();
        
        cout << current.roomCode << " " << current.movement << endl;
        
        if (s.peek().movement > premovement) {
            criticalCount++;
        }
        
        premovement = current.movement;
        
        s.pop();
    }
    
    cout << "Critical: " << criticalCount << endl;
    
    cout << "Highest: " << highestRoom;

}


// ============================================================
// DO NOT MODIFY
// ============================================================

int main()
{
    solve();

    return 0;
}